/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my;

import org.junit.Test;
import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

/**
 *
 * @author Lobarev Sergey
 */
public class VectorTest {
    
    public VectorTest() {
    }
    /**
     * Test of null vector, of class Vector.
     */
    @Test
    public void testNullVector() throws IOException {
        System.out.println("TestNullVector");
        new FileVector(new File("TestNullVector.txt"), "out.txt");
        try {
        	if ((new FileInputStream("out.txt").available())!=(new FileInputStream("TestNullVectorResult.txt").available()))
        		fail("File not found");
        } 
        catch (FileNotFoundException e1) {
        	fail("File not found");
        }
    }
    /**
     * Test of rotating vectors, of class Vector.
     */
    @Test
    public void testRotateVector() throws IOException {
        System.out.println("TestRotateVector");
        new FileVector(new File("TestRotateVector.txt"), "out.txt");
        try {
        	if ((new FileInputStream("out.txt").available())!=(new FileInputStream("TestRotateVectorResult.txt").available()))
        		fail("File not found");
        } 
        catch (FileNotFoundException e1) {
        	fail("File not found");
        }
    }
    /**
     * Test a lot of vectors, of class Vector.
     */
    @Test
    public void testManyVectors() throws IOException {
        System.out.println("TestManyVector");
        new FileVector(new File("TestManyVector.txt"), "out.txt");
        try {
        	if ((new FileInputStream("out.txt").available())!=(new FileInputStream("TestManyVectorResult.txt").available()))
        		fail("File not found");
        } 
        catch (FileNotFoundException e1) {
        	fail("File not found");
        }
    }
    /**
     * Test of long vectors, of class Vector.
     */
    @Test
    public void testLongVector() throws IOException {
        System.out.println("TestLongVector");
        new FileVector(new File("TestLongVector.txt"), "out.txt");
        try {
        	if ((new FileInputStream("out.txt").available())!=(new FileInputStream("TestLongVectorResult.txt").available()))
        		fail("File not found");
        } 
        catch (FileNotFoundException e1) {
        	fail("File not found");
        }
    }
    /**
     * Test of big vectors, of class Vector.
     */
    @Test
    public void testBigVector() throws IOException {
        System.out.println("TestBigVector");
        new FileVector(new File("TestBigVector.txt"), "out.txt");
        try {
        	if ((new FileInputStream("out.txt").available())!=(new FileInputStream("TestBigVectorResult.txt").available()))
        		fail("File not found");
        } 
        catch (FileNotFoundException e1) {
        	fail("File not found");
        }
    }
}