package my;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EditFrame extends JFrame implements ActionListener
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = -5329214853628105431L;
	private JRadioButton jrb1,jrb2,jrb3, jrb4, jrb5,jrb6,jrb7, jrb8;
	 private JButton jbt1,jbt2,jbt3,jbt4,jbt5,jbt6;
	 private ButtonGroup bg, bg2;
	 FuncPaintingPanel pg;
	 public void actionPerformed(ActionEvent e)
	 {
	// ����������� �������� ��������� �������, � � ����������� �� ���� �������� ��� 
	// ������� �������
		  if (e.getSource().equals(jrb1)){
			  pg.setColor(Color.blue);
			   pg.repaint();// ����������� ������� �������
		  }
		  if (e.getSource().equals(jrb2)) {
			  pg.setColor(Color.red);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jrb3)) {
			  pg.setColor(Color.green);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jrb4)) {
			   pg.setColor(Color.black);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt1)){
			   if (pg.getSizeLine()+1<=10) pg.setSizeLine(pg.getSizeLine()+1);
			   if (pg.getSizeLine()+1>10) jbt1.setEnabled(false); 
			   jbt2.setEnabled(true); 
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt2)){
			   if (pg.getSizeLine()-1>0) pg.setSizeLine(pg.getSizeLine()-1);
			   if (pg.getSizeLine()-1<=0) jbt2.setEnabled(false);
			   jbt1.setEnabled(true); 
			   pg.repaint();
		  }
		  
		  if (e.getSource().equals(jrb6)){
			  pg.setColorMax(Color.blue);
			   pg.repaint();// ����������� ������� �������
		  }
		  if (e.getSource().equals(jrb7)) {
			  pg.setColorMax(Color.red);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jrb8)) {
			  pg.setColorMax(Color.green);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jrb5)) {
			   pg.setColorMax(Color.black);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt5)){
			   if (pg.getSizeLineMax()+1<=10) pg.setSizeLineMax(pg.getSizeLineMax()+1);
			   if (pg.getSizeLineMax()+1>10) jbt1.setEnabled(false); 
			   jbt2.setEnabled(true); 
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt6)){
			   if (pg.getSizeLineMax()-1>0) pg.setSizeLineMax(pg.getSizeLineMax()-1);
			   if (pg.getSizeLineMax()-1<=0) jbt2.setEnabled(false);
			   jbt1.setEnabled(true); 
			   pg.repaint();
		  }
		  
		  if (e.getSource().equals(jbt3)){
			   pg.deleteLast();
			   pg.recalc();
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt4)){
			   pg.deleteAll();
			   pg.recalc();
			   pg.repaint();
		  }
	 }
	 
	 public EditFrame(FuncPaintingPanel p)
	 {
		  super("Settings");
		  //setLayout(new FlowLayout());
		  setLayout(new GridLayout(7,2));
		  pg=p ;
		  setResizable(false); 
		  jrb4 = new JRadioButton("Black",true);
		  jrb1 = new JRadioButton("Blue",true);
		  jrb2 = new JRadioButton("Red",false);
		  jrb3 = new JRadioButton("Green",false);
		  jbt1 = new JButton("Size of all+");
		  jbt2 = new JButton("Size of all-");
		  jrb5 = new JRadioButton("Black",true);
		  jrb6 = new JRadioButton("Blue",true);
		  jrb7 = new JRadioButton("Red",false);
		  jrb8 = new JRadioButton("Green",false);
		  jbt5 = new JButton("Size of max+");
		  jbt6 = new JButton("Size of max-");
		  jbt3 = new JButton("Remove last");
		  jbt4 = new JButton("Remove all");
		  jbt1.addActionListener(this);
		  jbt2.addActionListener(this);
		  jbt3.addActionListener(this);
		  jbt4.addActionListener(this);
		  jbt5.addActionListener(this);
		  jbt6.addActionListener(this);
		  jrb4.addActionListener(this);
		  jrb1.addActionListener(this);
		  jrb2.addActionListener(this);
		  jrb3.addActionListener(this);
		  jrb5.addActionListener(this);
		  jrb6.addActionListener(this);
		  jrb7.addActionListener(this);
		  jrb8.addActionListener(this);
		  bg = new ButtonGroup();
		  bg.add(jrb4);
		  bg.add(jrb1);
		  bg.add(jrb2);
		  bg.add(jrb3);
		  bg2 = new ButtonGroup();
		  bg2.add(jrb5);
		  bg2.add(jrb6);
		  bg2.add(jrb7);
		  bg2.add(jrb8);
		  add(jrb4);
		  add(jrb1);
		  add(jrb2);
		  add(jrb3);
		  add(jbt1);
		  add(jbt2);
		  add(jrb5);
		  add(jrb6);
		  add(jrb7);
		  add(jrb8);
		  add(jbt5);
		  add(jbt6);
		  add(jbt3);
		  add(jbt4);
	 }
}