package my;
import java.io.*;
import java.util.*;
import java.math.*;
import java.util.List;

/**
 * The work with file class
 *
 * @author Lobarev Sergey
 */
class FileVector{
    private static final int Integer = 0;
	private ArrayList<Object> scanVectorFile;
    private double[] angles;
    private int N, dim;
    private PrintStream out;
/**
 * Constructor FileVector
 * @param File name_file, String outputFileName
 * @throws FileNotFoundException if not correct name_file
 */
    FileVector(File fileName, String outputFileName) throws FileNotFoundException{
    	if(!fileName.exists())
            throw new ArrayIndexOutOfBoundsException("No input file.");
        if (outputFileName!=null) 
        	out = new PrintStream(new File(outputFileName));
        else
        	out = System.out;
        read(fileName);
        
       
        if(scanVectorFile.size() != 0){
        	//writeInfoAboutAll();
        	rotate();
        }
        out.close();
    }
/**
 * Read file
 * @param File name_file
 * @throws FileNotFoundException if not correct data file
 */
    public void read(File fileName) throws FileNotFoundException{
        scanVectorFile = new ArrayList<Object>();
        Scanner in = new Scanner(fileName);
        try{
        	
            N = in.nextInt();
            angles = new double[N];
            dim = in.nextInt();
            readLines(in);
        }catch(NoSuchElementException e){
            System.out.println("Wrong element");
        }
        in.close();
    }	
/**
 * Read lines with vectors from file
 * @param Scanner in
 */
    private void readLines(Scanner in){ 
	    for(int i=0;i<N;i++){
	        try{
	        	double[] elem = new double[dim];
	        	for(int j=0;j<dim;j++) elem[j] = in.nextDouble();
	            scanVectorFile.add(new Vector(dim, elem));
	            angles[i] = in.nextDouble();
	        }catch(NoSuchElementException e){
	            System.out.println("For Vector not find digits!");
	        }
	    }
    }	
/**
 * Method getArrayList
 * @return ArrayList scanVectorFile
 */
    public ArrayList getArrayList(){
        return scanVectorFile;
    }
/**
 * Writer File information about Vectors
 */
    public void writeInfoAboutAll(){
    	out.println("-------------------------------------");
        for(int i=0; i<scanVectorFile.size();i++){
        	Vector vector = (Vector)scanVectorFile.get(i);
            out.println((i+1)+") "+vector.toString());
            out.println("Length = "+vector.getNorm());
            out.println("Angle with oX: "+vector.getAngleWithOX());
            out.println("Rotating to angle: "+angles[i]);
            out.println("-------------------------------------");
        }
    }
/**
 * Writer File information about Vector
 * @param int number, String err
 */
    public void writeInfoAboutOne(int number, String err){
    	Vector vector = (Vector)scanVectorFile.get(number);
        out.println((number+1)+") "+vector.toString());
        out.println("Length = "+vector.getNorm());
        out.println("Angle with oX: "+vector.getAngleWithOX());
        out.println("Rotated to angle: "+angles[number]);
        out.println("Error: "+err);
        out.println("-------------------------------------");
    }
/**
 * Rotating vectors to it's angles
 */
    public void rotate(){
        for(int i=0; i<scanVectorFile.size();i++){
	        try{
	        	Vector vector = (Vector)scanVectorFile.get(i);
	        	vector.rotateToAngle(angles[i]);
	        	writeInfoAboutOne(i, "no");
	        }
	        catch (ArithmeticException e){
	        	writeInfoAboutOne(i, e.toString());
	        }
        }
    }
}