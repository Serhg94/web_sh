package my;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;

public class FuncPaintingPanel extends JPanel
{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int sizemax;
	 private Color colormax;
	 private int size;
	 private Color color;
	 private double max;
	 private double lenght;
	 private int maxnumber;
	 private ArrayList<Object> points;
	 private JLabel status;

     private double round(double data)
     {
          return new java.math.BigDecimal(data).setScale(2, java.math.BigDecimal.ROUND_HALF_UP).doubleValue();
     }
	 
	 public FuncPaintingPanel()
	 {
		  size = 2; // ������� �����
		  color = Color.black;
		  sizemax = 3; // ������� �����
		  colormax = Color.black;
		  max = 0;
		  maxnumber = 0;
		  lenght = 0;
		  points = new ArrayList<Object>();
	      setLayout(new BorderLayout()); // ��������� ��������� ����������
	      status = new JLabel("Start painting!");
	      add(status,BorderLayout.SOUTH);
		  this.addMouseListener(new MouseListener()
		  {
			  public void mouseClicked(MouseEvent e)
			  {
				  points.add(new Point(e.getX(), e.getY()));
				  recalc();
				  repaint();
			  }
			  public void mousePressed(MouseEvent e){}
			  public void mouseEntered(MouseEvent e){}
			  public void mouseReleased(MouseEvent e){}
			  public void mouseExited(MouseEvent e){}
		  });
	 }
	 public void recalc()
	 {
		  max = 0;
		  lenght = 0;
          for(int i=0; i<points.size()-1;i++){
	       	  Point a = (Point)points.get(i);
	       	  Point b = (Point)points.get(i+1);
	       	  double l = Math.sqrt((a.getX()-b.getX())*(a.getX()-b.getX())+(a.getY()-b.getY())*(a.getY()-b.getY()));
	       	  lenght += l; 
	       	  if (l>max) {max = l; maxnumber = i;}
          }
          status.setText("Lenght = "+round(lenght)+", Count of points = "+points.size());
	 }
	 public void paint(Graphics in)
	 {
		  super.paint(in);
		  Graphics2D g = (Graphics2D) in; 
		  if (points.size()>=2)
          for(int i=0; i<points.size()-1;i++){
        	  Point a = (Point)points.get(i);
        	  Point b = (Point)points.get(i+1);
    		  g.setColor(color);
    		  g.setStroke(new BasicStroke(size));
        	  if (i == maxnumber){
        		  g.setColor(colormax);
        		  g.setStroke(new BasicStroke(sizemax));
        	  }
        	  g.drawLine((int)a.getX(), (int)a.getY(), (int)b.getX(), (int)b.getY());
          }
	 }
	 public void deleteLast()
	 {
		  if (points.size()>=1){
			  points.remove(points.size()-1);
          }
	 }
	 public void deleteAll()
	 {
		 points.removeAll(points);
	 }
 // ������ getXXX(), setXXX() - �������
	 public int getSizeLine() {
		 return size;
	 }
	 public void setSizeLine(int nx) {
		 this.size = nx;
	 }
	 public Color getColor() {
		 return color;
	 }
	 public void setColor(Color c) {
		 this.color = c;
	 }
	 public int getSizeLineMax() {
		 return sizemax;
	 }
	 public void setSizeLineMax(int nx) {
		 this.sizemax = nx;
	 }
	 public Color getColorMax() {
		 return colormax;
	 }
	 public void setColorMax(Color c) {
		 this.colormax = c;
	 }
}