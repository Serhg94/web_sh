package my;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class ToolsFrame extends JFrame implements ActionListener
{
	 private JButton jbt1,jbt2,jbt3,jbt4,jbt5,jbt6,jbt7,jbt8, jbt9;
	 FuncPaintingPanel pg;
	 public void actionPerformed(ActionEvent e)
	 {
		  if (e.getSource().equals(jbt1))
		  {
			   if( pg.getNy()== 5 ) jbt2.setEnabled( true );
			   pg.setNy(pg.getNy() + 5);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt2))
		  {
			   pg.setNy(pg.getNy() - 5);
			   pg.repaint();
			   if(pg.getNy() == 5) jbt2.setEnabled(false);
		  }
		  if (e.getSource().equals(jbt3)) 
		  {
			   pg.setKy(pg.getKy() - (double)0.01);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt4))
		  {
			   pg.setKy(pg.getKy() + (double)0.01);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt5))
		  {
			   pg.setKx(pg.getKx() - (double)0.01);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt6))
		  {
			   pg.setKx(pg.getKx() + (double)0.01);
			   pg.repaint();
		  }
		  if (e.getSource().equals(jbt7))
		  {
			   if(pg.getHx() >=0.01) jbt8.setEnabled(true);
			   pg.setHx( pg.getHx()+(double)0.01);
			   pg.repaint();
			   if(pg.getHx() >= 1) jbt7.setEnabled(false);
		  }
		  if (e.getSource().equals(jbt8))
		  {
			   if(pg.getHx() <=1) jbt7.setEnabled(true);
			   pg.setHx( pg.getHx()-(double)0.01);
			   pg.repaint();
			   if(pg.getHx() <=0.01) jbt8.setEnabled(false);
		  }
		  if (e.getSource().equals(jbt9))
		  {
			   pg.setKx((double)0.5);
			   pg.setKy((double)0.5);
			   pg.repaint();
		  }
	 }
	 public void keyActionPerformed(int key)
	 {
		  if (key==1)
		  {
			   if( pg.getNy()== 5 ) jbt2.setEnabled( true );
			   pg.setNy(pg.getNy() + 5);
			   pg.repaint();
		  }
		  if (key==2)
		  {
			   pg.setNy(pg.getNy() - 5);
			   pg.repaint();
			   if(pg.getNy() == 5) jbt2.setEnabled(false);
		  }
		  if (key==3)
		  {
			   pg.setKy(pg.getKy() - (double)0.01);
			   pg.repaint();
		  }
		  if (key==4)
		  {
			   pg.setKy(pg.getKy() + (double)0.01);
			   pg.repaint();
		  }
		  if (key==5)
		  {
			   pg.setKx(pg.getKx() - (double)0.01);
			   pg.repaint();
		  }
		  if (key==6)
		  {
			   pg.setKx(pg.getKx() + (double)0.01);
			   pg.repaint();
		  }
		  if (key==7)
		  {
			   if(pg.getHx() >=0.01) jbt8.setEnabled(true);
			   pg.setHx( pg.getHx()+(double)0.01);
			   pg.repaint();
			   if(pg.getHx() >= 1) jbt7.setEnabled(false);
		  }
		  if (key==8)
		  {
			   if(pg.getHx() <=1) jbt7.setEnabled(true);
			   pg.setHx( pg.getHx()-(double)0.01);
			   pg.repaint();
			   if(pg.getHx() <=0.01) jbt8.setEnabled(false);
		  }
		  if (key==9)
		  {
			   pg.setKx((double)0.5);
			   pg.setKy((double)0.5);
			   pg.repaint();
		  }
	 }
	 public ToolsFrame(FuncPaintingPanel p)
	 {
		  super("�����������");
		  setLayout(new GridLayout(5,2));// ��������� ���������� ��������� ����������
		  pg=p ;
		  jbt1 = new JButton("������� +");
		  jbt2 = new JButton("������� -");
		  jbt4 = new JButton("�����");
		  jbt3 = new JButton("����");
		  jbt6 = new JButton("�����");
		  jbt5 = new JButton("������");
		  jbt7 = new JButton("������+");
		  jbt8 = new JButton("������-");
		  jbt9 = new JButton("� �����");
		  jbt1.addActionListener(this);
		  jbt2.addActionListener(this);
		  jbt4.addActionListener(this);
		  jbt3.addActionListener(this);
		  jbt6.addActionListener(this);
		  jbt5.addActionListener(this);
		  jbt7.addActionListener(this);
		  jbt8.addActionListener(this);
		  jbt9.addActionListener(this);
		  setResizable(false); 
		  add(jbt1);
		  add(jbt2);
		  add(jbt4);
		  add(jbt3);
		  add(jbt6);
		  add(jbt5);
		  add(jbt7);
		  add(jbt8);
		  add(jbt9);
	 }
}