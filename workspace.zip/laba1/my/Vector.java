package my;
import java.math.*;
/**
 * The work with vector class
 * @author Lobarev Sergey
 */
public class Vector {
	double[] elements;
	int dimension;
	/**
 * Constructor
 * @param integer dimension, array of integer elements
 */
    Vector(int dim, double[] elem){
        elements = elem;
		dimension = dim;
    }
/**
 * Get dimension of vector
 */
    public int getDim(){
        return dimension;
    }
/**
 * Round
 * @param double data
 */
    private double round(double data){
        return new java.math.BigDecimal(data).setScale(3, java.math.BigDecimal.ROUND_HALF_UP).doubleValue();
    }
/**
 * Get angle between oX and vector
 */
    public double getAngleWithOX() {
    	double cos=0;
    	if (this.getNorm()!=0)
    		cos = elements[0]/this.getNorm();
    	else return 0;
    	return round((Math.acos(cos)*180)/Math.PI);
    }
/**
 * Get lenght of vector
 */
    public double getNorm(){
    	double norm = 0;
    	for (int i = 0; i < dimension; i++)
    		norm += elements[i]*elements[i]; 
        return round(Math.sqrt(norm));
    }
/**
 * Rotate vector to angle aroung (0,0)
 * @param double angle
 */
    public void rotateToAngle(double angle) {
    	if (dimension!=2) 
    		throw new ArithmeticException("Wrong dimension, can't rotate!");
    	double x = elements[0];
    	double y = elements[1];
    	angle = (angle*Math.PI)/180;
    	elements[0]=round(x*Math.cos(angle)-y*Math.sin(angle));
    	elements[1]=round(x*Math.sin(angle)+y*Math.cos(angle));
    }
/**
 * Print elements of vector
 */
    public String toString() {
		String result = "Vector{ ";
		for (int i = 0; i < dimension; i++){
			if (i == dimension-1) result += elements[i]+" }";
			else result += elements[i]+", "; 
		}		
        return result;
    }
}
