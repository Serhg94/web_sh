package my;
import java.util.*;
import java.io.*;
/**
 * The main class
 * @author Lobarev Sergey
 */
class VectorRotater{
/**
 * Main function
 * @param args the command line arguments
 */
    public static void main(String [] args){
        System.out.println("Hello World!");


        Set<Integer> set;
        boolean maxf=false, minf=false;
		int max = 0, min = 0;
		set = new HashSet<Integer>();
		Random random = new Random();
		for(int i=0; i<20;i++)
			set.add((Integer)random.nextInt());
		Iterator<Integer> itr = set.iterator();
		while (itr.hasNext()) {
			int val = itr.next().intValue();
			if (!maxf) {max = val; maxf = true;}
			if (!minf) {min = val; minf = true;}
			if (val<min) min = val;
			if (val>max) max = val;
		}
		System.out.println("Max = "+max);
		System.out.println("Min = "+min);
		set.remove((Integer)max);
		set.add((Integer)max+min);
		itr = set.iterator();
		while (itr.hasNext()) {
			System.out.println(" = "+itr.next().intValue());
		}
        
        
		
		
		
        System.out.println("-------------------------------------");
            try{
            	if(args.length > 1) 
            		new FileVector(new File(args[0]), args[1]);
            	else
            		new FileVector(new File(args[0]), null);
            }catch (ArrayIndexOutOfBoundsException e){
                System.out.println("Error. No input file. Enter names of input and output(optionally) files.");
                System.out.println("For example: laba1.jar in.txt out.txt");
            }catch(FileNotFoundException e){
                System.out.println("BED" +e);
            }			
    }
}