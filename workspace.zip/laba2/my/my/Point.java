package my;
/**
 * The work with point class
 */
class Point{
    private double x, y;
/**
 * Constructor
 * @param not param
 */
    Point(){
        this(0, 0);
    }
/**
 * Constructor
 * @param double x, double y
 */
    Point(double x, double y){
        this.x = x;
        this.y = y;
    }
/**
 * Get coordinate x
 */
    public double getX(){
        return x;
    }
/**
 * Set coordinate x
 */
    public void setX(double x){
        this.x = x;
    }
/**
 * Get coordinate y
 */
    public double getY(){
        return y;
    }
/**
 * Set coordinate y
 */
    public void setY(double y){
        this.y = y;
    }
/**
 * Print coordinate point (x;y)
 */
    public String toString() {
        return "Point{"+"x="+x+", y="+y+"}";
    }
}